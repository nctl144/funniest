def joke():
    return "no u nigga"
